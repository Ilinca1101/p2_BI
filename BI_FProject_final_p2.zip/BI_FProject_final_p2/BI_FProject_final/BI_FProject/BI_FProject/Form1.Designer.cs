﻿using System.Windows.Forms.DataVisualization.Charting;

namespace BI_FProject
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            dataGridView1 = new DataGridView();
            comboBoxTop = new ComboBox();
            labelOldestBook = new Label();
            labelNewestBook = new Label();
            labelAuthorStats = new Label();
            chart1 = new Chart();
            panelMenu = new Panel();
            button2 = new Button();
            button1 = new Button();
            buttonTask1 = new Button();
            buttonTask2 = new Button();
            buttonTask3 = new Button();
            buttonTask4 = new Button();
            buttonTask5 = new Button();
            panelTask1 = new Panel();
            panelTask2 = new Panel();
            panelTask3 = new Panel();
            panelTask4 = new Panel();
            panelTask5 = new Panel();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)chart1).BeginInit();
            panelMenu.SuspendLayout();
            SuspendLayout();
            // 
            // dataGridView1
            // 
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(20, 20);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.RowHeadersWidth = 62;
            dataGridView1.Size = new Size(700, 400);
            dataGridView1.TabIndex = 0;
            // 
            // comboBoxTop
            // 
            comboBoxTop.Anchor = AnchorStyles.Top | AnchorStyles.Bottom;
            comboBoxTop.DropDownStyle = ComboBoxStyle.DropDownList;
            comboBoxTop.Items.AddRange(new object[] { "Top 5", "Top 10" });
            comboBoxTop.Location = new Point(8, 410);
            comboBoxTop.Margin = new Padding(2);
            comboBoxTop.Name = "comboBoxTop";
            comboBoxTop.Size = new Size(131, 28);
            comboBoxTop.TabIndex = 0;
            comboBoxTop.SelectedIndexChanged += ComboBoxTop_SelectedIndexChanged;
            // 
            // labelOldestBook
            // 
            labelOldestBook.Location = new Point(0, 0);
            labelOldestBook.Name = "labelOldestBook";
            labelOldestBook.Size = new Size(100, 23);
            labelOldestBook.TabIndex = 0;
            // 
            // labelNewestBook
            // 
            labelNewestBook.Location = new Point(0, 0);
            labelNewestBook.Name = "labelNewestBook";
            labelNewestBook.Size = new Size(100, 23);
            labelNewestBook.TabIndex = 0;
            // 
            // labelAuthorStats
            // 
            labelAuthorStats.Location = new Point(0, 0);
            labelAuthorStats.Name = "labelAuthorStats";
            labelAuthorStats.Size = new Size(100, 23);
            labelAuthorStats.TabIndex = 0;
            // 
            // chart1
            // 
            chart1.Location = new Point(20, 20);
            chart1.Name = "chart1";
            chart1.Size = new Size(700, 400);
            chart1.TabIndex = 0;
            // 
            // panelMenu
            // 
            panelMenu.BorderStyle = BorderStyle.FixedSingle;
            panelMenu.Controls.Add(button2);
            panelMenu.Controls.Add(button1);
            panelMenu.Controls.Add(comboBoxTop);
            panelMenu.Controls.Add(buttonTask1);
            panelMenu.Controls.Add(buttonTask2);
            panelMenu.Controls.Add(buttonTask3);
            panelMenu.Controls.Add(buttonTask4);
            panelMenu.Controls.Add(buttonTask5);
            panelMenu.Location = new Point(8, 8);
            panelMenu.Margin = new Padding(2);
            panelMenu.Name = "panelMenu";
            panelMenu.Size = new Size(160, 801);
            panelMenu.TabIndex = 1;
            // 
            // button2
            // 
            button2.Location = new Point(8, 351);
            button2.Name = "button2";
            button2.Size = new Size(131, 44);
            button2.TabIndex = 0;
            button2.Text = "button2";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // button1
            // 
            button1.Location = new Point(8, 288);
            button1.Name = "button1";
            button1.Size = new Size(131, 43);
            button1.TabIndex = 5;
            button1.Text = "button1";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // buttonTask1
            // 
            buttonTask1.Location = new Point(8, 8);
            buttonTask1.Margin = new Padding(2);
            buttonTask1.Name = "buttonTask1";
            buttonTask1.Size = new Size(144, 53);
            buttonTask1.TabIndex = 0;
            buttonTask1.Text = "Cele mai bine vândute cărți";
            buttonTask1.Click += ButtonTask1_Click;
            // 
            // buttonTask2
            // 
            buttonTask2.Location = new Point(8, 74);
            buttonTask2.Margin = new Padding(2);
            buttonTask2.Name = "buttonTask2";
            buttonTask2.Size = new Size(144, 32);
            buttonTask2.TabIndex = 1;
            buttonTask2.Text = "Distribuția genurilor";
            buttonTask2.Click += ButtonTask2_Click;
            // 
            // buttonTask3
            // 
            buttonTask3.Location = new Point(8, 122);
            buttonTask3.Margin = new Padding(2);
            buttonTask3.Name = "buttonTask3";
            buttonTask3.Size = new Size(144, 30);
            buttonTask3.TabIndex = 2;
            buttonTask3.Text = "Anii de publicare";
            buttonTask3.Click += ButtonTask3_Click;
            // 
            // buttonTask4
            // 
            buttonTask4.Location = new Point(8, 170);
            buttonTask4.Margin = new Padding(2);
            buttonTask4.Name = "buttonTask4";
            buttonTask4.Size = new Size(144, 51);
            buttonTask4.TabIndex = 3;
            buttonTask4.Text = "Autorii cei mai productivi";
            buttonTask4.Click += ButtonTask4_Click;
            // 
            // buttonTask5
            // 
            buttonTask5.Location = new Point(8, 238);
            buttonTask5.Margin = new Padding(2);
            buttonTask5.Name = "buttonTask5";
            buttonTask5.Size = new Size(144, 32);
            buttonTask5.TabIndex = 4;
            buttonTask5.Text = "Limba originală";
            buttonTask5.Click += ButtonTask5_Click;
            // 
            // panelTask1
            // 
            panelTask1.Location = new Point(176, 8);
            panelTask1.Margin = new Padding(2);
            panelTask1.Name = "panelTask1";
            panelTask1.Size = new Size(1195, 801);
            panelTask1.TabIndex = 2;
            panelTask1.Visible = false;
            // 
            // panelTask2
            // 
            panelTask2.Location = new Point(176, 8);
            panelTask2.Margin = new Padding(2);
            panelTask2.Name = "panelTask2";
            panelTask2.Size = new Size(600, 360);
            panelTask2.TabIndex = 3;
            panelTask2.Visible = false;
            // 
            // panelTask3
            // 
            panelTask3.Location = new Point(176, 8);
            panelTask3.Margin = new Padding(2);
            panelTask3.Name = "panelTask3";
            panelTask3.Size = new Size(600, 360);
            panelTask3.TabIndex = 4;
            panelTask3.Visible = false;
            // 
            // panelTask4
            // 
            panelTask4.Location = new Point(176, 8);
            panelTask4.Margin = new Padding(2);
            panelTask4.Name = "panelTask4";
            panelTask4.Size = new Size(600, 360);
            panelTask4.TabIndex = 5;
            panelTask4.Visible = false;
            // 
            // panelTask5
            // 
            panelTask5.Location = new Point(176, 8);
            panelTask5.Margin = new Padding(2);
            panelTask5.Name = "panelTask5";
            panelTask5.Size = new Size(600, 360);
            panelTask5.TabIndex = 6;
            panelTask5.Visible = false;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1382, 820);
            Controls.Add(panelTask1);
            Controls.Add(panelTask2);
            Controls.Add(panelTask3);
            Controls.Add(panelTask4);
            Controls.Add(panelTask5);
            Controls.Add(panelMenu);
            Margin = new Padding(2);
            Name = "Form1";
            Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ((System.ComponentModel.ISupportInitialize)chart1).EndInit();
            panelMenu.ResumeLayout(false);
            ResumeLayout(false);
        }

        #endregion

        private DataGridView dataGridView1;
        private ComboBox comboBoxTop;
        private Label labelOldestBook;
        private Label labelNewestBook;
        private Label labelAuthorStats;
        private Chart chart1;
        private Panel panelMenu;
        private Button buttonTask1;
        private Button buttonTask2;
        private Button buttonTask3;
        private Button buttonTask4;
        private Button buttonTask5;
        private Panel panelTask1;
        private Panel panelTask2;
        private Panel panelTask3;
        private Panel panelTask4;
        private Panel panelTask5;
        private Button button1;
        private Button button2;
    }
}
